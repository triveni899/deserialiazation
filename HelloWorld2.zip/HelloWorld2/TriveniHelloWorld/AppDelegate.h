//
//  AppDelegate.h
//  TriveniHelloWorld
//
//  Created by Navneet  Magotra on 2/2/16.
//  Copyright © 2016 Triveni Banpela. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    AVAudioPlayer *player;
}

@property (strong, nonatomic) UIWindow *window;


@end


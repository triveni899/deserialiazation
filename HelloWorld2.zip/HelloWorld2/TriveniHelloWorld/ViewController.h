//
//  ViewController.h
//  TriveniHelloWorld
//
//  Created by Navneet  Magotra on 2/2/16.
//  Copyright © 2016 Triveni Banpela. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *labelHelloWorld;

- (IBAction)ButtonHelloWorld:(id)sender;

@end

